<?php session_start(); 
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - Order History</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Order History</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
	<div class="shopping_cart_area mt-60">
        <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="table_desc">
                            <div class="cart_page table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product_thumb">ORDER</th>
                                            <th class="product_name">DATE</th>
                                            <th class="product-price">TOTAL</th>
                                            <th class="product_quantity">STATUS</th>
											<th>ACTION</th>
                                            <th class="product_total">DETAIL</th>
                                        </tr>
									</thead>
                                    <tbody>
								<?php if(isset($_SESSION['SESS-ID'])){ 
							            $uid= $_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM checkout WHERE u_id='$uid' ORDER BY o_id DESC";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									  
							         ?>
                                <tr>
									<form method="post">
									<td align="center" style="text-align: center" class="price" data-label="ID"><b>#<?php echo $row['o_id'] ?></b></td>	
                                    <td data-label="Date" style="text-align: center"><?php echo $row['date'] ?></td>
                                    <td data-label="Total" style="text-align: center">$<?php echo $row['total']; ?></td>
                                    <td data-label="Status" style="text-align: center">
										<?php
										$s=$row['status'];
									   if($s==0)
									   {?>
										   <a onClick="return confirm('Do you want to cancel order?')" href="order_history.php?delete=<?php echo $row['o_id']; ?>" class="ps-btn1" style="color: orange; font-size: 14px;"><i class="fa fa-clock-o"></i> Processing</a>
									 <?php  
									   }
									   else if($s==1)
									   {?>
										   <div class="ps-btn1" style="color:limegreen; padding-left: 10px; padding-right: 10px; padding-top: 10px; padding-bottom: 10px; font-size: 14px; border-radius: 4px;"><i class="fa fa-check-square-o"></i> Delivered</div>
									  <?php } else if($s==2) {
										?>
										    <div class="ps-btn1" style="color:red; padding-left: 10px; padding-right: 10px; padding-top: 10px; padding-bottom: 10px; font-size: 14px; border-radius: 4px;"><i class="fa fa-close"></i> Canceled</div>
										<?php }?>
                                    </td>
									<td data-label="Action" style="text-align: center">
										<?php
										$s=$row['status'];
									   if($s==0)
									   {?>
										   <a onClick="return confirm('Do you want to cancel order?')" href="order_history.php?delete=<?php echo $row['o_id']; ?>" class="ps-btn1" style="background-color: #242424; padding-left: 20px; padding-right: 20px; padding-top: 10px; padding-bottom: 10px; font-size: 14px; color: white; border-radius: 4px;">Cancel</a>
									 <?php  
									   }
									   else if ($s==1)
									   {?>
										  <i class="fa fa-thumbs-up"></i>
									  <?php }
										else if ($s==2)
									   {?>
										  <i class="fa fa-thumbs-down"></i>
									  <?php }
										?>
                                    </td>	
										
									<td data-label="Detail" style="text-align: center"><a class="ps-btn1" style="background-color: #1953B4; padding-left: 20px; padding-right: 20px; padding-top: 10px; padding-bottom: 10px; font-size: 14px; color: white; border-radius: 4px;" href="order_detail.php?invoice=<?php echo $row['o_id'] ?>">View</a></td>	
                               
								</form>		
								</tr>
                             
								<?php
											$uid= $_SESSION['SESS-ID'];
											$q="SELECT * FROM checkout WHERE status='0' AND u_id='$uid'";
									        $qry=mysqli_query($con,$q);
									   
									         if(isset($_GET['delete']))
											{
												$d=$_GET['delete'];
												$status=2; 
												$delete="UPDATE checkout SET status='$status' where o_id='$d'";
												$f=mysqli_query($con,$delete);
												 
												 $num= mysqli_num_rows($f);
													if($num==2)
													{
														echo "<script>window.location.replace('order_cancel.php')</script>";
													}
													else{

														echo "<script>window.location.replace('order_history.php')</script>";
													} 
												
											}
								     }
                                         } 
							         ?>
                            		  </tbody>
								</table>
							</div>
						</div>
					</div>
			</div>
		</div>
	</div>
		
    <?php 
		include('footer.php'); 
		?>
	
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>