<?php session_start(); ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - cart page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

   <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Shopping Cart</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--shopping cart area start -->
    <div class="shopping_cart_area mt-60">
        <div class="container">
            <form method="post">
                <div class="row">
                    <div class="col-12">
                        <div class="table_desc">
                            <div class="cart_page table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product_thumb">Image</th>
                                            <th class="product_name">Product Name</th>
                                            <th class="product-price">Price</th>
                                            <th class="product_quantity">Quantity</th>
                                            <th class="product_total">Total</th>
											<th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
							            $uid= $_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM cart WHERE status = '0' AND u_id='$uid'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									   $pid=$row['p_id'] ;
									   $qry = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r1=mysqli_query($con,$qry);
								   while($r=mysqli_fetch_array($r1))
								   {
							         ?>		
                                        <tr>
                                            <form method="post">
                                            <td class="product_thumb"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($r['image'])?>" alt=""></a></td>
                                            <td class="product_name"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><?php echo $r['p_name'] ?></a></td>
                                            <td class="product-price">$<?php echo $row['p_price'] ?></td>
                                            <td class="product_quantity"><input name="qnty1" value="<?php echo $row['p_qty'] ?>" type="number" ></td>
										   <td class="product_total">$<?php echo $row['g_total'] ?></td>
											<td>
                                             <div class="input-group btn-block">
											 <span class="input-group-btn">
                                              <button type="submit" name="upd<?php echo $row['p_id'] ?>" class="btn btn-primary"><i class="fa fa-refresh"></i></button>
                                              <button type="submit" name="del<?php echo $row['p_id'] ?>" class="btn btn-danger pull-right"><i class="fa fa-times-circle"></i></button>
                                              </span>
                                              </div>
                                               </td>
											</form>
                                        </tr>
										<?php 
	                                  $pid=$row['p_id'];
									  if(isset($_REQUEST['upd'.$pid]))
									   {
										       $uid=$_SESSION['SESS-ID'];
											   
										            $qnty=$_REQUEST['qnty1'];
										            $p_price=$row['p_price'];
													$p_total=$p_price*$qnty;
													$p_tax=0;
													$p_ship=0;
													$g_total=$p_ship+$p_total+$p_tax;
                                                     $q = "UPDATE cart SET p_qty = '$qnty', p_total='$p_total', g_total='$g_total' WHERE  u_id = '$uid' AND p_id = '$pid'";
													 mysqli_query($con,$q);
										  	
										    $qty=$row['p_qty'];
										 
										  if($qnty<$qty)
										  {
											  $sub=$qty-$qnty;
											  $rr=$r['quantity']+$sub;
											  $qry = "UPDATE product SET quantity = '$rr' WHERE  p_id='$pid'";
					                     	mysqli_query($con,$qry);
										  }
										  else
										  {
											  
										    $qty=$qnty - $qty;
											 if($qty<0)
										  {
											  $qty= -1 * $qty;
											  
											  
										  }  
											$lastquantity= $r['quantity'] -  $qty;
										  	$qry = "UPDATE product SET quantity = '$lastquantity' WHERE  p_id ='$pid'";
					                     	mysqli_query($con,$qry);
										  }
										  
										  echo "<script>window.location.replace('cart.php')</script>";
									   }
									   ?>		
										<?php
									 if(isset($_GET['del'.$pid]))
									{
										$pid=$row['p_id'];
										$qty=$row['p_qty'];
										$pro=$r['quantity'];
										$rr=$qty+$pro;
										$q = "UPDATE product SET quantity = '$rr' WHERE  p_id ='$pid'";
					                    mysqli_query($con,$q);
										$d=$_GET['delete'];
										$delete="DELETE FROM cart where u_id='$d'";
										mysqli_query($con,$delete);
										echo "<script>window.location.replace('index.php')</script>";
									}
									
									?>
										<?php } } ?>
                                    </tbody>
                                </table>
                            </div>
						</div>
                    </div>
                </div>
                <!--coupon code area start-->
                <div class="coupon_area">
                    <div class="row">
						<div class="col-lg-3 col-md-3"></div>
                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code right">
								
                                <h3>Cart Totals</h3>
                                <div class="coupon_inner">
                                    <div class="cart_subtotal">
										
                                        <p>Subtotal</p>
                                        <p class="cart_amount">£
										<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(p_total) as p_tot FROM cart WHERE status = '0' AND u_id='$uid'";
										$sumr=mysqli_query($con,$sum);
										while($s=mysqli_fetch_array($sumr))
										{
												echo $s['p_tot'];
										}?>
										</p>
                                    </div>
                                    <div class="cart_subtotal ">
                                        <p>Shipping</p>
                                        <p class="cart_amount">Free Shiping</p>
                                    </div>
                                    <div class="cart_subtotal">
                                        <p>Total</p>
                                        <p class="cart_amount">$
										<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(g_total) as g_tot FROM cart WHERE status = '0' AND u_id='$uid'";
										$sumr=mysqli_query($con,$sum);
										while($s=mysqli_fetch_array($sumr))
										{
												echo $s['g_tot'];
										}?>
										</p>
                                    </div>
                                    <div class="checkout_btn">
                                        <a href="checkout.php">Proceed to Checkout</a>
                                    </div>
                                </div>
								
                            </div>
                        </div>
                    </div>
                </div>
                <!--coupon code area end-->
            </form>
        </div>
    </div>
	
    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>
</html>