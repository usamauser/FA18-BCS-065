<?php session_start(); ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - wishlist page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Wishlist</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->


    <!--wishlist area start -->
    <div class="wishlist_area mt-60">
        <div class="container">
                <div class="row">
					<div class="col-sm-12 col-md-3 col-lg-3">
                        <div class="dashboard_tab_button">
                            <ul class="nav flex-column dashboard-list">
								<li ><a href="user_info.php"  class="nav-link">Account details</a></li>
								<li><a href="addresses.php"  class="nav-link">Addresses</a></li>
                                <li><a href="userorder_history.php" class=" nav-link">Orders</a></li>
								<li><a href="user_wishlist.php"  class="active nav-link">Wishlist</a></li>
                                <li><a href="logout.php" class="nav-link">logout</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-9 col-lg-9">
                        <div class="table_desc wishlist">
                            <div class="cart_page table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product_thumb">Image</th>
                                            <th class="product_name">Product</th>
                                            <th class="product-price">Price</th>
                                            <th class="product_quantity">Stock Status</th>
                                            <th class="product_total">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<form method="post">
										<?php 
												if(isset($_SESSION['SESS-ID'])){
							            $uid= $_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM wishlist WHERE u_id='$uid'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									   $pid=$row['p_id'] ;
									   $qry = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r1=mysqli_query($con,$qry);
								   while($r=mysqli_fetch_array($r1))
								   {
							         ?>		
                                        <tr>
                                            <td class="product_thumb"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($r['image']) ?>" alt=""></a></td>
                                            <td class="product_name"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><?php echo $r['p_name'] ?></a></td>
                                            <td class="product-price">
										<?php 
										 $p =$r['sale_price'];
									   		if($p<=0)
										{
											echo $r['price'];
										}
								   			else
								   		{
												
									   		echo $r['sale_price'];
								   		}
								   ?>
											</td>
                                            <td class="product_quantity">
											<?php 
									   			$qnty =$r['quantity'];
									   				if($qnty>0)
										    {   
										 		echo "Available";
										   }
								   				else
											{
												echo "Out of Stock";
								   			}
								   ?>
											</td>
                                            <td class="product_total"><button type="submit" name="cart1<?php echo $r['p_id'] ?>" class="btn btn-primary"><i class="fa fa-cart-plus"></i></button>
											<a onClick="return confirm(Do you want to remove this item from wishlist)" href="wishlist.php?delete=<?php echo $row['id']?>"><i class="fa fa-remove"></i></a></td>
											</tr>
									    </form>
										<?php 
						 $pid=$r['p_id'];
					  	 $qty=$r['quantity'];
					if(isset($_REQUEST['cart1'.$pid]))	{
						$o_id=0;
						if($r['sale_price']<=0) {
							$p_price=$r['price'];
						}
						else{
							$p_price=$r['sale_price'];
						}
						$p_qty=1;
						$p_total=$p_price*$p_qty;
						$p_tax=0;
						$p_ship=0;
						$g_total=$p_ship+$p_total+$p_tax;
						$status=0;
						
						$qr= "INSERT INTO cart(id,u_id,o_id,p_id,p_price,p_qty,p_total,p_tax,p_ship,g_total,status)VALUES(NULL,'$uid','$o_id','$pid','$p_price','$p_qty','$p_total','$p_tax','$p_ship','$g_total','$status')";
						mysqli_query($con,$qr);
						$qty--;
						$qry= "UPDATE product SET quantity = '$qty' WHERE p_id='$pid'";
						mysqli_query($con,$qry);
						echo "<script> window.location.replace('wishlist.php')</script>";
					} ?>
										
										<?php
									if(isset($_GET['delete']))
									{
										$d=$_GET['delete'];
										$delete="DELETE FROM wishlist where id='$d'";
										mysqli_query($con,$delete);
										echo "<script>window.location.replace('wishlist.php')</script>";
									}
									
									?>
										<?php } } } ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
        </div>
    </div>
    <!--wishlist area end -->

    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>

    <script src="assets/js/main.js"></script>



</body>
</html>