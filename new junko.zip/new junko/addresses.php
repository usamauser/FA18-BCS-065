<?php session_start(); 
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - my account</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">


</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>My account</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!-- my account start  -->
    <section class="main_content_area">
        <div class="container">
			<?php if(isset($_SESSION['SESS-ID'])){ 
							            $uid= $_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM register WHERE u_id='$uid'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
							         ?>
            <div class="account_dashboard">
                <div class="row">
                    <div class="col-sm-12 col-md-3 col-lg-3">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
								<li><a href="user_info.php"  class="nav-link">Account details</a></li>
								<li><a href="addresses.php"  class="nav-link active">Addresses</a></li>
                                <li><a href="userorder_history.php" class="nav-link">Orders</a></li>
								<li><a href="user_wishlist.php"  class="nav-link">Wishlist</a></li>
                                <li><a href="logout.php" class="nav-link">logout</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-9 col-lg-9">
                        <div class="tab-content dashboard_content">
                            <form method="post">
                                    <h3> User Address</h3>
                                <div class="account_login_form">
                                    <div class="row">
										<div class="col-sm-12">
                                            <div class="form-group">
												<label>Shipping address</label>
												<div class="form-group__content">
													<textarea class="form-control" rows="2" name="address"><?php echo $row['address'] ?></textarea>
												</div>
                                    </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input class="form-control" name="city" type="text" value="<?php echo $row['city'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>State</label>
                                                <input class="form-control" name="state" type="text" value="<?php echo $row['state'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <input class="form-control" name="country" type="text" value="<?php echo $row['country'] ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Zip Code</label>
                                                <input class="form-control" name="zipcode" type="text" value="<?php echo $row['zip_code'] ?>">
                                            </div>
                                        </div>
										
                                        
                                    </div>
                                </div>
                                <div class="update_button primary_btn default_button form-group submit" align="right">
                                   <button type="submit" name="upd<?php echo $row['u_id'] ?>">Update</button>
								</div>
								
                            </form>
							
                        </div>
                    </div>
                </div>
            </div>
			<?php 
										 $uid=$row['u_id'];
									  if(isset($_REQUEST['upd'.$uid]))
									   {
										  $address=$_REQUEST['address'];
										  $city=$_REQUEST['city'];
										  $state=$_REQUEST['state'];
										  $country=$_REQUEST['country'];
										  $zipcode=$_REQUEST['zipcode'];
										  
                                          $q = "UPDATE register SET address = '$address', city='$city', state='$state', country='$country', zip_code='$zipcode' WHERE u_id = '$uid'";
									      mysqli_query($con,$q);
										  echo "<script>window.location.replace('addresses.php')</script>";
								   }
								   } } ?>
        </div>
    </section>
    <!-- my account end   -->

    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>

</html>