<?php session_start(); 
if(isset($_GET['msg']))
{
	$checkouid=$_GET['msg'];
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - Order Tracking</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Order Traking</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="order-notes">
            <div class="container">
                <div class="section-pt">
                    <h2 align="center"> Order Tracking </h2>
                    <p>To track your order please enter your Order ID in the box below and press the "Track" button. This was given to you on your receipt and in the confirmation email you should have received.</p>
                </div>
				<div class="Checkout_section">
                    <form class="checkout_form" action="index.php" method="get">
                        <div class="form-group">
                            <label>Order ID</label>
                            <input class="form-control" type="text" placeholder="Found in your order confimation email">
                        </div>
                        <div class="form-group">
                            <label>Billing Email</label>
                            <input class="form-control" type="text" placeholder="">
                        </div>
                        <div class="form-group" align="center">
                            <button class="btn-primary" style="background-color: #1953B4; border: none; color: white; padding: 15px 32px; text-align: center; font-size: 16px;">Track Your Order</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
	
	

    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>



</body>
</html>