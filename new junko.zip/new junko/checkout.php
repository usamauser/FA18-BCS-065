<?php session_start(); ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - checkout page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Checkout</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--Checkout page section-->
    <div class="Checkout_section mt-60">
        <div class="container">
            <div class="checkout_form">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <form method="post">
                            <h3>Billing Details</h3>
                            <div class="row">

                                <div class="col-lg-6 mb-20">
                                    <label>First Name <span>*</span></label>
                                    <input type="text" name="f_name">
                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label>Last Name <span>*</span></label>
                                    <input type="text" name="l_name">
                                </div>
                                <div class="col-12 mb-20">
                                    <label for="country">country <span>*</span></label>
                                    <input type="text" name="country">
                                </div>
                                <div class="col-12 mb-20">
                                    <label>Street address <span>*</span></label>
                                    <input placeholder="House number and street name" type="text" name="address">
                                </div>
                                
                                <div class="col-12 mb-20">
                                    <label> State <span>*</span></label>
                                    <input type="text" name="state">
                                </div>
								<div class="col-12 mb-20">
                                    <label> Zip Code <span>*</span></label>
                                    <input type="text" name="zip_code">
                                </div>
								<div class="col-12 mb-20">
                                    <label>City  <span>*</span></label>
                                    <input type="text" name="city">
                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label>Phone<span>*</span></label>
                                    <input type="text" name="phone">

                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label> Email Address <span>*</span></label>
                                    <input type="text" name="email">
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                            <h3>Your order</h3>
                            <div class="order_table table-responsive">
								 <table>
                                    <thead>
                                            <th>Product</th>
                                            <th>Total</th>
                                    </thead>
                                    <tbody>
										<?php
							            $uid=$_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM cart WHERE status = '0' AND u_id='$uid'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									   $pid=$row['p_id'] ;
									   $qry = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r1=mysqli_query($con,$qry);
								   while($r=mysqli_fetch_array($r1))
								   {
							         ?>	
                                        <tr>
                                            <td class="product_name"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><?php echo $r['p_name'] ?></a><strong> × <?php echo $row['p_qty'] ?></strong></td>
                                            <td class="product-price">$<?php echo $row['p_price'] ?></td>
										</tr>
										<?php } } ?>
                                    </tbody>
								   </table>
								<br>
                                            <h4 class="cart_subtotal">Cart Subtotal<span>$
												<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(p_total) as p_tot FROM cart WHERE status = '0' AND u_id='$uid'";
										$sumr=mysqli_query($con,$sum);
										while($s=mysqli_fetch_array($sumr))
										{
												echo $s['p_tot'];
										}?>
										</span></h4>
								<br>
                                        <h3 class="cart_total">Order Total<span>$
												<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(g_total) as g_tot FROM cart WHERE status = '0' AND u_id='$uid'";
										$sumr=mysqli_query($con,$sum);
										while($s=mysqli_fetch_array($sumr))
										{
												echo $s['g_tot'];
										}?>
											</span></h3>
                                       
                            </div>
                            <div class="payment_method">
                                <div class="order_button">
                                    <button type="submit" name="btn7" >Proceed to Payment</button>
                                </div>
                            </div>
							</form>
							<?php 
									$uid= $_SESSION['SESS-ID'];
									$sum="SELECT sum(g_total) as g_tot FROM cart WHERE status = '0' AND u_id='$uid'";
									$sumr=mysqli_query($con,$sum);
									while($s=mysqli_fetch_array($sumr))
										{
									if(isset($_REQUEST['btn7']))
									{
										$total= $s['g_tot'];
										$uid=$_SESSION['SESS-ID'];
										$name = $_REQUEST['f_name'];
										$lastname = $_REQUEST['l_name'];
										$phone = $_REQUEST['phone'];
										$e_mail = $_REQUEST['email'];
										$address = $_REQUEST['address'];
										$city = $_REQUEST['city'];
										$state = $_REQUEST['state'];
										$country = $_REQUEST['country'];
										$zip_code = $_REQUEST['zip_code'];
										$date =        date ('j/M/Y');


   								$insert = "INSERT INTO checkout(o_id,u_id,f_name,l_name,email,address,city,state,country,zip_code,phone,total,status,date) VALUES(NULL,'$uid','$name','$lastname','$e_mail','$address','$city','$state','$country','$zip_code','$phone','$total',0,'$date')";
								mysqli_query($con,$insert);
								$q= "SELECT * FROM checkout WHERE u_id='$uid' AND status='0' ORDER BY o_id DESC LIMIT 0,1";
								$qry=mysqli_query($con,$q);
								$r=mysqli_fetch_array($qry);
								$invoice=$r['o_id'];
								echo "<script>window.location.replace('payment.php?msg=$invoice')</script>";
							
									}	}
						?>
                   
					</div>
                </div>
            </div>
        </div>
    </div>
    <!--Checkout page section end-->

    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>



</body>
</html>