<?php session_start(); 
if(isset($_GET['msg']))
{
	$checkouid=$_GET['msg'];
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - Order Cancle</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Order Cancle</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="Checkout_section">
            <div class="container">
                <div class="footer_payment">
                    <h2><i class="fa fa-thumbs-o-up"></i> Order Canceled !</h2>
                    <p>Order has been cancled. Please visit<a href="order_history.php"><b style="color: #1953B4"> here</b></a> to check your order history.</p>
                </div>
            </div>
        </section>

    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>



</body>
</html>