<?php
session_start();
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - about us</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

   <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>about us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--about section area -->
    <section class="about_section mt-60">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12">
					<?php
	                             $q="SELECT * FROM about ";
							     $r=mysqli_query($con,$q);
							     while($row=mysqli_fetch_array($r))
					 { ?>
                    <figure>
                        <div class="about_thumb">
                            <img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($row['img']) ?>" alt="">
                        </div>
                        <figcaption class="about_content">
                            <h1><?php echo $row['name']; ?></h1>
                            <p><?php echo $row['des']; ?></p>
                        </figcaption>
                    </figure>
					<?php } ?>
                </div>
            </div>
        </div>
    </section>
    <!--about section end-->

    <!--services img area-->
    
    <!--services img end-->

    <!--chose us area start-->
    <div class="choseus_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="single_chose">
                        <div class="chose_icone">
                            <img src="assets/img/about/About_icon1.png" alt="">
                        </div>
                        <div class="chose_content">
                            <h3>Money Back Guarantee</h3>
                            <p>Erat metus sodales eget dolor consectetuer, porta ut purus at et alias, nulla ornare
                                velit amet</p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="single_chose">
                        <div class="chose_icone">
                            <img src="assets/img/about/About_icon2.png" alt="">
                        </div>
                        <div class="chose_content">
                            <h3>Creative Design</h3>
                            <p>Erat metus sodales eget dolor consectetuer, porta ut purus at et alias, nulla ornare
                                velit amet</p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="single_chose">
                        <div class="chose_icone">
                            <img src="assets/img/about/About_icon3.png" alt="">
                        </div>
                        <div class="chose_content">
                            <h3>High Quality</h3>
                            <p>Erat metus sodales eget dolor consectetuer, porta ut purus at et alias, nulla ornare
                                velit amet</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--chose us area end-->

    <!--team area start-->
    <div class="team_area">
        <div class="container">
            <div class="row">
				<?php $up="SELECT * FROM team WHERE status='1'";
													$u=mysqli_query($con, $up);
													while($r3=mysqli_fetch_array($u))
													{ ?>
                <div class="col-lg-3 col-md-6">
                    <article class="team_member">
                        <figure>
                            <div class="team_thumb">
                                <img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($r3['image']) ?>" alt="">
                            </div>
                            <figcaption class="team_content">
                                <h3><?php echo $r3['name']; ?></h3>
								<p> <?php echo $r3['email']; ?></p>
                                <h5 style="margin-right: 20px;"><?php echo $r3['position']; ?></h5>
								<ul style="margin-right: 20px;">
                                    <li><a href="<?php echo $r3['twitter'] ?>"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="<?php echo $r3['fb'] ?>"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="<?php echo $r3['linkedin'] ?>"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="<?php echo $r3['insta'] ?>"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </figcaption>
                        </figure>
                    </article>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <!--team area end-->

    <!--footer area start-->
    <?php include('footer.php') ?>
    <!--footer area end-->
     
	<script src="assets/js/plugins.js"></script>

    <script src="assets/js/main.js"></script>

</body>
</html>