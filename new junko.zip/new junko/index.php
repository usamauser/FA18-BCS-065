<?php session_start();	
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - Electronics eCommerce HTML Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS 
    ========================= -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
	
	.btn-outline-info {
    color: #1953b4;
    border-color: #1953b4;
	
}
	.btn-outline-info:hover
	{
		background-color: #1953b4;
		border-color: ##1953b4;
	}
	
		</style>
<body>

   <?php include('header.php') ?>

    <!--slider area start-->
    <section class="slider_section mb-70">
        <div class="slider_area owl-carousel">
			<?php 
							         
	                                 $ch = "SELECT * FROM slider WHERE status = '1'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									   $pid=$row['p_id'] ;
									   $qry = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r1=mysqli_query($con,$qry);
								   while($r=mysqli_fetch_array($r1))
								   {
							         ?>	
			
           <div class="single_slider d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <div class="row justify-content-center align-items-center">
                <div class="col-lg-7 col-md-7 text-md-left text-center">
                  <div class="from-bottom">
                    <div class="h1 text-body text-normal mb-2 pt-1"><?php echo $r['p_name'] ?></div>
                  </div>
					<a class="button" href="product-details.php?p_id=<?php echo $r['p_id'] ?>">Shopping Now</a>
                </div>
                <div class="col-md-5 padding-bottom-2x"><img class="d-block" src="<?php echo 'data:image/jpeg;base64,'. base64_encode($row['img']); ?>" alt="<?php echo $r['p_name'] ?>"></div>
              </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
			<?php } }?>
        </div>
    </section>
    <!--slider area end-->

    <!--shipping area start-->
    
    <!--shipping area end-->

    <!--banner area start-->
    <div class="banner_area mb-40">
        <div class="container">
            <div class="row">
				 
			<?php
								 $a="SELECT * FROM banner";
							     $b=mysqli_query($con,$a);
							     while($c1=mysqli_fetch_array($b))
					 { 
								 $pid=$c1['p_id'];
								 $a1="SELECT * FROM product WHERE p_id='$pid' AND status='1' ";
							     $a2=mysqli_query($con,$a1);
							     while($c2=mysqli_fetch_array($a2))
					 { 
			?>
                <div class="col-lg-3 col-md-3">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="product-details.php?p_id=<?php echo $c2['p_id'] ?>">
			<img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($c1['img'])?>" alt=""></a>
                        </div>
                    </div>
                </div>
				<?php } } ?>
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--product area start-->
    <section class="product_area mb-46">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>On Sale</h2>
                    </div>
                </div>
            </div>
            <div class="product_carousel product_column5 owl-carousel">
				<?php
	                             $q6="SELECT * FROM product WHERE sale_price > '0' AND status = '1'";
							     $r6=mysqli_query($con,$q6);
							     while($row3=mysqli_fetch_array($r6))
					 { ?>
				<form method="post">
                <article class="single_product">
                    <figure>
                        <div class="product_thumb">
                            <a class="primary_img" href="product-details.php?p_id=<?php echo $row3['p_id'] ?>"><img
                                    src="<?php echo 'data:image/jpeg;base64,' . base64_encode($row3['image']) ?>" alt=""></a>
							<div class="label_product">
                                    <span class="label_sale">sale</span>
                                </div>
                            <div class="action_links">
                                <ul>
                                    <li class="wishlist">
										<?php if(isset($_SESSION['SESS-ID'])) {?>
										<button style="background: none; border: none;" type="submit" name="wish1<?php echo $row3['p_id'] ?>"><a class="fa fa-heart-o" data-toggle="tooltip" data-placement="top" title="Add to Whishlist"></a></button>
									<?php } else {?> 
									<a href="login.php" title="Login for Add to Wishlist"><i class="fa fa-heart" aria-hidden="true"></i></a></li>
									<?php }?>
                                </ul>
                            </div>
                            <div >
								<?php if(isset($_SESSION['SESS-ID'])) {?>
						<button style="background: none; border: none;" type="submit" name="cart3<?php echo $row3['p_id'] ?>"><a style="margin: 30px;" class="btn btn-outline-info" data-toggle="tooltip" data-placement="top" title="Add To Cart"> Add to cart</a></button>
								<?php } else {?> 
						<div class="add_to_cart">
								<a href="login.php"  title="Login to Add To Cart">Add to cart</a>
									</div>
								<?php }?>
							</div>
                        </div>
                        <figcaption class="product_content">
                            <div class="price_box">
                                <span class="old_price">$<?php echo $row3['price'] ?></span>
                                <span class="current_price">$<?php echo $row3['sale_price'] ?></span>
                            </div>
                            <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row3['p_id'] ?>"><?php echo $row3['p_name'] ?></a></h3>
                        </figcaption>
                    </figure>
                </article>
					</form>
				<?php 
						 $pid=$row3['p_id'];
					  	 $qty=$row3['quantity'];
					if(isset($_REQUEST['cart3'.$pid]))	{
						$o_id=0;
						if($row3['sale_price']<=0) {
							$p_price=$row3['price'];
						}
						else{
							$p_price=$row3['sale_price'];
						}
						$qry1 = "SELECT * FROM cart WHERE u_id = '$uid' AND p_id = '$pid' AND status='0'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
													$up="SELECT * FROM cart WHERE p_id='$pid' AND u_id='$uid'";
													$u=mysqli_query($con, $up);
													while($r3=mysqli_fetch_array($u))
													{ 
													  
													 $qnty=$r3['p_qty']+1;
													$p_total=$p_price*$qnty;
													$p_tax=0;
													$p_ship=0;
													$g_total=$p_ship+$p_total+$p_tax;
                                                     $qrr = "UPDATE cart SET p_qty = '$qnty', p_total='$p_total', g_total='$g_total' WHERE  u_id = '$uid' AND p_id = '$pid'";
										         	mysqli_query($con,$qrr);
													 
													} 
													
												}
						else{
						$p_qty=1;
						$p_total=$p_price*$p_qty;
						$p_tax=0;
						$p_ship=0;
						$g_total=$p_ship+$p_total+$p_tax;

						$status=0;
						
						$qr= "INSERT INTO cart(id,u_id,o_id,p_id,p_price,p_qty,p_total,p_tax,p_ship,g_total,status)VALUES(NULL,'$uid','$o_id','$pid','$p_price','$p_qty','$p_total','$p_tax','$p_ship','$g_total','$status')";
						mysqli_query($con,$qr);
						$qty--;
						$qry= "UPDATE product SET quantity = '$qty' WHERE p_id='$pid'";
						mysqli_query($con,$qry);
						echo "<script> window.location.replace('index.php')</script>";
						}
					} ?>
						 
				<?php
									   
										$pid=$row3['p_id'];
									   if(isset($_REQUEST['wish1'.$pid]))
													   {
										$uid=$_SESSION['SESS-ID'];
										$qry1 = "SELECT * FROM wishlist WHERE u_id = '$uid' AND p_id = '$pid'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
												 
												}
										        else
												{
													$qrr= "INSERT INTO wishlist (id, p_id,u_id) VALUES ( NULL, '$pid', '$uid')";
																mysqli_query($con,$qrr);
																echo "<script> window.location.replace('index.php')</script>";
												}
																
													   } ?>
									
				
				
				<?php } ?>
            </div>
        </div>
    </section>
    <!--product area end-->

    <!--banner area start-->
    <div class="banner_area mb-40">
        <div class="container">
            <div class="row">
				 
			<?php
								 $a="SELECT * FROM banner";
							     $b=mysqli_query($con,$a);
							     while($c1=mysqli_fetch_array($b))
					 { 
								 $pid=$c1['p_id'];
								 $a1="SELECT * FROM product WHERE p_id='$pid' AND status='1' ";
							     $a2=mysqli_query($con,$a1);
							     while($c2=mysqli_fetch_array($a2))
					 { 
			?>
                <div class="col-lg-3 col-md-3">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="product-details.php?p_id=<?php echo $c2['p_id'] ?>">
			<img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($c1['img'])?>" alt=""></a>
                        </div>
                    </div>
                </div>
				<?php } } ?>
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--top- category area start-->
    <!--top- category area end-->

    <!--featured product area start-->
    <section class="featured_product_area mb-70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title">
                        <h2>All Products</h2>
                    </div>
                </div>
            </div>
            <div class="row featured_container featured_column3">
				<?php
	                             $q5="SELECT * FROM product WHERE status = '1'";
							     $r5=mysqli_query($con,$q5);
							     while($row2=mysqli_fetch_array($r5))
					 { ?>
				<form method="post">
                <div class="col-lg-4 ">
                    <article class="single_product">
                        <figure>
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php?p_id=<?php echo $row2['p_id'] ?>"><img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($row2['image']) ?>" alt=""></a>
                            </div>
                            <figcaption class="product_content">
                                <div class="price_box">
                                    <span class="current_price">$<?php  $g=$row2['sale_price'];
										if($g<=0)
											   {
												  echo $row2['price'];
												   
											   }
										       
											   {
												  echo $row2['sale_price']; 
												   
											   }
										?></span>
                                </div>
                                <h3 class="product_name"><a href="product-details.php?p_id=<?php echo $row2['p_id'] ?>"><?php echo $row2['p_name'] ?></a></h3>
                                <div class="mb-15">
							<?php if(isset($_SESSION['SESS-ID'])) {?>
						<button class="btn btn-outline-info"  style="background: none; border: none; padding-left:  25px; padding-top: 80px; font-size: 30px;" type="submit" name="cart2<?php echo $row2['p_id'] ?>"> Add to cart</button>
							<?php } else {?>
							<div class="add_to_cart">
								<a href="login.php"  title="Login to Add To Cart">Add to cart</a>
									</div>
							<?php } ?>
						</div>
                            </figcaption>
                        </figure>
                    </article>
                </div>
					</form>
				<?php 
						 $pid=$row2['p_id'];
					  	 $qty=$row2['quantity'];
					if(isset($_REQUEST['cart2'.$pid]))	{
						$o_id=0;
						if($row2['sale_price']<=0) {
							$p_price=$row2['price'];
						}
						else{
							$p_price=$row2['sale_price'];
						}
						$qry1 = "SELECT * FROM cart WHERE u_id = '$uid' AND p_id = '$pid' AND status='0'";
												$r1=mysqli_query($con,$qry1);
												$row1 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
													$up="SELECT * FROM cart WHERE p_id='$pid' AND u_id='$uid'";
													$u=mysqli_query($con, $up);
													while($r3=mysqli_fetch_array($u))
													{ 
													  
													 $qnty=$r3['p_qty']+1;
													$p_total=$p_price*$qnty;
													$p_tax=0;
													$p_ship=0;
													$g_total=$p_ship+$p_total+$p_tax;
                                                     $qrr = "UPDATE cart SET p_qty = '$qnty', p_total='$p_total', g_total='$g_total' WHERE  u_id = '$uid' AND p_id = '$pid'";
										         	mysqli_query($con,$qrr);
													 
													} 
													
												}
						else{
						$p_qty=1;
						$p_total=$p_price*$p_qty;
						$p_tax=0;
						$p_ship=0;
						$g_total=$p_ship+$p_total+$p_tax;
						$status=0;
						
						$qr= "INSERT INTO cart(id,u_id,o_id,p_id,p_price,p_qty,p_total,p_tax,p_ship,g_total,status)VALUES(NULL,'$uid','$o_id','$pid','$p_price','$p_qty','$p_total','$p_tax','$p_ship','$g_total','$status')";
						mysqli_query($con,$qr);
						$qty--;
						$qry= "UPDATE product SET quantity = '$qty' WHERE p_id='$pid'";
						mysqli_query($con,$qry);
						echo "<script> window.location.replace('index.php')</script>";
							}
					} 
						 ?>
				<?php
									   
										$pid=$row2['p_id'];
									   if(isset($_REQUEST['wish3'.$pid]))
													   {
										$uid=$_SESSION['SESS-ID'];
										$qry1 = "SELECT * FROM wishlist WHERE u_id = '$uid' AND p_id = '$pid'";
												$r1=mysqli_query($con,$qry1);
												$row2 = mysqli_fetch_assoc($r1);
												if((mysqli_num_rows($r1))>0)
												{
												 
												}
										        else
												{
													$qrr= "INSERT INTO wishlist (id, p_id,u_id) VALUES ( NULL, '$pid', '$uid')";
																mysqli_query($con,$qrr);
																echo "<script> window.location.replace('index.php')</script>";
												}
																
													   }
										
								?>	
				<?php } ?>
            </div>
        </div>
    </section>
    <!--featured product area end-->

    <!--product area start-->
    
    <!--product area end-->

    <!--banner area start-->
    <div class="banner_area mb-40">
        <div class="container">
            <div class="row">
				 
			<?php
								 $a="SELECT * FROM banner";
							     $b=mysqli_query($con,$a);
							     while($c1=mysqli_fetch_array($b))
					 { 
								 $pid=$c1['p_id'];
								 $a1="SELECT * FROM product WHERE p_id='$pid' AND status='1' ";
							     $a2=mysqli_query($con,$a1);
							     while($c2=mysqli_fetch_array($a2))
					 { 
			?>
                <div class="col-lg-3 col-md-3">
                    <div class="single_banner mb-30">
                        <div class="banner_thumb">
                            <a href="product-details.php?p_id=<?php echo $c2['p_id'] ?>">
			<img src="<?php echo 'data:image/jpeg;base64,' . base64_encode($c1['img'])?>" alt=""></a>
                        </div>
                    </div>
                </div>
				<?php } } ?>
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--product area start-->
    
    <!--product area end-->

    <!--blog area start-->
    
    <!--blog area end-->

    <!--brand area start-->
    <div class="brand_area mb-70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="brand_container owl-carousel">
						<?php 
	                                 $ch = "SELECT * FROM brand WHERE status = '1'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									 
							         ?>	
                        <div class="brand_items">
                            <div class="single_brand">
                                <a href="#"><img src="<?php echo 'data:image/png;base64,'. base64_encode($row['img']); ?>"</a>
                            </div>
                        </div>
						<?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--brand area end-->

     <?php include('footer.php') ?>

    <!-- modal area start-->
    <div class="modal fade" id="modal_box" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal_body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-5 col-sm-12">
                                <div class="modal_tab">
                                    <div class="tab-content product-details-large">
                                        <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product1.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab2" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product2.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab3" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product3.jpg" alt=""></a>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="tab4" role="tabpanel">
                                            <div class="modal_tab_img">
                                                <a href="#"><img src="assets/img/product/product5.jpg" alt=""></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal_tab_button">
                                        <ul class="nav product_navactive owl-carousel" role="tablist">
                                            <li>
                                                <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab"
                                                    aria-controls="tab1" aria-selected="false"><img
                                                        src="assets/img/product/product1.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab2" role="tab"
                                                    aria-controls="tab2" aria-selected="false"><img
                                                        src="assets/img/product/product2.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link button_three" data-toggle="tab" href="#tab3"
                                                    role="tab" aria-controls="tab3" aria-selected="false"><img
                                                        src="assets/img/product/product3.jpg" alt=""></a>
                                            </li>
                                            <li>
                                                <a class="nav-link" data-toggle="tab" href="#tab4" role="tab"
                                                    aria-controls="tab4" aria-selected="false"><img
                                                        src="assets/img/product/product5.jpg" alt=""></a>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-7 col-sm-12">
                                <div class="modal_right">
                                    <div class="modal_title mb-10">
                                        <h2>Handbag feugiat</h2>
                                    </div>
                                    <div class="modal_price mb-10">
                                        <span class="new_price">$64.99</span>
                                        <span class="old_price">$78.99</span>
                                    </div>
                                    <div class="modal_description mb-15">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia iste
                                            laborum ad impedit pariatur esse optio tempora sint ullam autem deleniti nam
                                            in quos qui nemo ipsum numquam, reiciendis maiores quidem aperiam, rerum vel
                                            recusandae </p>
                                    </div>
                                    <div class="variants_selects">
                                        <div class="variants_size">
                                            <h2>size</h2>
                                            <select class="select_option">
                                                <option selected value="1">s</option>
                                                <option value="1">m</option>
                                                <option value="1">l</option>
                                                <option value="1">xl</option>
                                                <option value="1">xxl</option>
                                            </select>
                                        </div>
                                        <div class="variants_color">
                                            <h2>color</h2>
                                            <select class="select_option">
                                                <option selected value="1">purple</option>
                                                <option value="1">violet</option>
                                                <option value="1">black</option>
                                                <option value="1">pink</option>
                                                <option value="1">orange</option>
                                            </select>
                                        </div>
                                        <div class="modal_add_to_cart">
                                            <form action="#">
                                                <input min="0" max="100" step="2" value="1" type="number">
                                                <button type="submit">add to cart</b>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="modal_social">
                                        <h2>Share this product</h2>
                                        <ul>
                                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                            <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a>
                                            </li>
                                            <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal area end-->

    <!-- JS
============================================ -->

    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>


<!-- Mirrored from demo.hasthemes.com/junko-preview/junko/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 10:46:52 GMT -->
</html>