<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - Join Us</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
.account_form button {
		  height: 40px;
		  border-radius: 5px;
}
input:focus{
		border-color:  #0063d1;
		transition: 1s;
}
	</style>
<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Sign Up</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!-- customer login start -->
    <div class="customer_login mt-60">
        <div class="container">
            <div class="row">
                <!--login area start-->
				<div class="col-lg-1 col-md-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
                    <div class="account_form">
                        <h1 style="color: #1953b4; padding-bottom: 30px;" align="center" >Sign Up</h1>
                        <form method="post" style="box-shadow: 2px 2px 10px 2px #ebebeb; padding-top: 50px; padding: 40px;">
                            <div class="row">
                                <div class="col-lg-6 mb-20">
                                    <label>First Name <span>*</span></label>
                                    <input type="text" name="name">
                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label>Last Name <span>*</span></label>
                                    <input type="text" name="lastname">
                                </div>
								<div class="col-lg-6 mb-20">
                                    <label>Phone <span>*</span></label>
                                    <input type="text" name="phone">

                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label> Email Address <span>*</span></label>
                                    <input type="text" name="email">

                                </div>
                                <div class="col-12 mb-20">
                                    <label>Street address <span>*</span></label>
                                    <input placeholder="House number and street name" type="text" name="address">
                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label>City <span>*</span></label>
                                    <input type="text" name="city">
                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label>State <span>*</span></label>
                                    <input type="text" name="state">
                                </div>
								<div class="col-12 mb-20">
                                    <label>Country <span>*</span></label>
                                    <input type="text" name="country">

                                </div>
								 <div class="col-lg-6 mb-20">
                                    <label>Zip Code <span>*</span></label>
                                    <input type="text" name="zip_code">
                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label>DOB <span>*</span></label>
                                    <input type="date" name="dob">
                                </div>
                                 <div class="col-lg-6 mb-20">
                                    <label>Password <span>*</span></label>
                                    <input type="password" name="password">
                                </div>
                                <div class="col-lg-6 mb-20">
                                    <label>Confirm Password <span>*</span></label>
                                    <input type="password" name="cpassword">
                                </div>
								
                            </div>
                                 <p align="center">
                                 <div align="center">
                                   <button type="submit" name="btn7" style="width: 50%;">Join Us</button>
                                </div>
                            </p>
                        </form>
					<?php 
							if(isset($_REQUEST['btn7']))
							{
								$name = $_REQUEST['name'];
								$lastname = $_REQUEST['lastname'];
								$phone = $_REQUEST['phone'];
								$e_mail = $_REQUEST['email'];
								$address = $_REQUEST['address'];
								$city = $_REQUEST['city'];
								$state = $_REQUEST['state'];
								$country = $_REQUEST['country'];
								$zip_code = $_REQUEST['zip_code'];
								$dob =        date ('j/M/Y');
								$date =        date ('j/M/Y');
								$password = $_REQUEST['password'];
								$cpassword = $_REQUEST['cpassword'];

   								$insert2= "INSERT INTO register(u_id,name,lastname,email,password,cpassword,address,city,state,country,zip_code,phone,status,dob,date) VALUES(NULL,'$name','$lastname','$e_mail','$password','$cpassword','$address','$city','$state','$country','$zip_code','$phone',0,'$dob','$date')";
								$as=mysqli_query($con,$insert2);
								echo "<script>window.location.replace('login.php')</script>";
							}?>
                    </div>
                </div>
				<div class="col-lg-1 col-md-1"></div>
                <!--login area start-->
            </div>
        </div>
    </div>
    <!-- customer login end -->

    <?php include('footer.php') ?>
	
    <script src="assets/js/plugins.js"></script>

    <script src="assets/js/main.js"></script>
    


</body>
</html>