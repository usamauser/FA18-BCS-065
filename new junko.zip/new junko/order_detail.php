<?php session_start(); 
if(isset($_GET['invoice']))
{
	$invoice=$_GET['invoice'];
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Junko - Order History</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<style>
	
	.btn-outline-info {
    color: #1953b4;
    border-color: #1953b4;
	
}
	.btn-outline-info:hover
	{background-color: #1953b4;
		border-color: ##1953b4;
	}
	
	
	</style>	

<body>

    <?php include('header.php') ?>

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>Order Detail</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
	<div class="shopping_cart_area mt-60">
        <div class="container">
			<h3>Order Details</h3>
			<div align="center" style="margin-bottom: 40px; margin-top: -30px;">
                    <h4>Invoice number <span style="color: blue;"><b><?php echo $invoice; ?></b></span>  </h4>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="table_desc">
							<div class="product_section">
                            <div class="cart_page table-responsive">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product_thumb">ID</th>
                                            <th class="product_name">PRODUCT NAME</th>
                                            <th class="product_total">PRICE</th>
                                            <th class="product_quantity">QUANTITY</th>
											<th class="product-price">TOTAL</th>
											
                                        </tr>
									</thead>
                                    <tbody>
								<?php if(isset($_SESSION['SESS-ID'])){ 
							            $uid= $_SESSION['SESS-ID'];
	                                 $ch = "SELECT * FROM cart WHERE status = '1' AND o_id='$invoice' AND u_id='$uid'";
								   $rr=mysqli_query($con,$ch);
								   while($row=mysqli_fetch_array($rr))
								   {
									   $pid=$row['p_id'] ;
									   $qry = "SELECT * FROM product WHERE  p_id='$pid'";
								   $r1=mysqli_query($con,$qry);
								   while($r=mysqli_fetch_array($r1))
								   {
							         ?>
                                <tr>
									<form method="post">
									<td align="center" data-label="ID"><b><?php echo $row['o_id'] ?></b></td>	
                                    <td data-label="Product">
                                        <div class="ps-product--cart">
                                            <div class="ps-product__thumbnail"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><img style="width: 100px; height: 100px;" src="<?php echo 'data:image/jpeg;base64,' . base64_encode($r['image'])?>" alt=""></a></div>
                                            <div class="ps-product__content"><a href="product-details.php?p_id=<?php echo $r['p_id'] ?>"><?php echo $r['p_name'] ?></a>
                                                <p>Sold By:<strong> <?php echo $r['sold_by'] ?></strong></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="price" data-label="Price" style="text-align: center">$<?php echo $row['p_price'] ?></td>
                                    <td data-label="Quantity" style="text-align: center"><?php echo $row['p_qty'] ?></td>
                                    <td data-label="Total" style="text-align: center">$<?php echo $row['p_total'] ?></td>
										
								</form>		
								</tr>
									<?php 
								   }
								           }
                                         } 
							         ?>
                            </tbody>
								</table>
							</div>
							</div>
						</div>
						</div>
						</div>		
			
						   <div class="row">
							   <a class="btn btn-outline-info" href="index.php">Back to Home</a>
					</div>
			<br>
					  <div class="coupon_area">
                    <div class="row">
						<div class="col-lg-6 col-md-6"></div>
                        <div class="col-12">
                            <div class="coupon_code right">
								
                                
                                <div class="coupon_inner">
                                    <div class="cart_subtotal">
										
                                        <p>Subtotal</p>
                                        <p class="cart_amount">£
										<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(p_total) as p_tot FROM cart WHERE u_id='$uid' AND o_id='$invoice' AND status='1'";
										$sumr=mysqli_query($con,$sum);
										while($sumrr=mysqli_fetch_array($sumr))
										{
											echo $sumrr['p_tot'];
										}?>
										</p>
                                    </div>
                                    <div class="cart_subtotal ">
                                        <p>Shipping</p>
                                        <p class="cart_amount">Free Shiping</p>
                                    </div>
                                    <div class="cart_subtotal">
                                        <p>Total</p>
                                        <p class="cart_amount">$
										<?php 
										$uid= $_SESSION['SESS-ID'];
										$sum="SELECT sum(g_total) as g_tot FROM cart WHERE u_id='$uid' AND o_id='$invoice' AND status='1'";
										$sumr=mysqli_query($con,$sum);
										while($sumrr=mysqli_fetch_array($sumr))
										{
											echo $sumrr['g_tot'];
										}?>
										</p>
                                    </div>
                                    
                                </div>
								
                            </div>
                        </div>
                    </div>
                </div>
                
						
					
			
		</div>
	</div>
		
    <?php 
		include('footer.php'); 
		?>
	
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>